import 'package:construction_technect/app/core/utils/imports.dart';

class MyTexts extends TextTheme {
  static const String Montserrat = 'Lato';

  /// Medium = 500 , light = 400 , bold = 600, ExtraBold = 700

  static TextStyle get medium14 => TextStyle(
    fontSize: 14.sp,
    fontWeight: FontWeight.w500,
    color: MyColors.black,
    fontFamily: Montserrat,
  );

  static TextStyle get medium12 => TextStyle(
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
    color: MyColors.black,
    fontFamily: Montserrat,
  );
  static TextStyle get medium10 => TextStyle(
    fontSize: 10.sp,
    fontWeight: FontWeight.w500,
    color: MyColors.black,
    fontFamily: Montserrat,
  );

  static TextStyle get light14 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 14.sp,
    fontWeight: FontWeight.w400,
    color: MyColors.black,
  );
  static TextStyle get light12 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
    color: MyColors.black,
  );
  static TextStyle get light16 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 16.sp,
    fontWeight: FontWeight.w400,
    color: MyColors.black,
  );

  static TextStyle get medium16 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 16.sp,
    fontWeight: FontWeight.w500,
    color: MyColors.black,
  );

  static TextStyle get light24 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 24.sp,
    fontWeight: FontWeight.w400,
    color: MyColors.black,
  );

  static TextStyle get light22 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 22.sp,
    fontWeight: FontWeight.w400,
    color: MyColors.black,
  );

  static TextStyle get bold14 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 14.sp,
    fontWeight: FontWeight.w600,
    color: MyColors.black,
  );

  static TextStyle get bold16 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 16.sp,
    fontWeight: FontWeight.w600,
    color: MyColors.black,
  );
  static TextStyle get bold12 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 12.sp,
    fontWeight: FontWeight.w600,
    color: MyColors.black,
  );

  static TextStyle get bold18 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 18.sp,
    fontWeight: FontWeight.w600,
    color: MyColors.black,
  );

  static TextStyle get extraBold20 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 20.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );

  static TextStyle get extraBold12 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 12.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );

  static TextStyle get extraBold14 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 14.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );

  static TextStyle get extraBold16 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 16.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );

  static TextStyle get extraBold22 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 22.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );

  static TextStyle get extraBold18 => TextStyle(
    fontFamily: Montserrat,
    fontSize: 18.sp,
    fontWeight: FontWeight.w700,
    color: MyColors.black,
  );
}
