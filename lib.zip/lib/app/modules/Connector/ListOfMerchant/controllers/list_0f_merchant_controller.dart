import 'package:construction_technect/app/core/utils/imports.dart';

class ListOfMerchantController extends GetxController {
  RxInt selectedCategory = 0.obs;
  RxInt selectedSubCategory = 0.obs;
  RxInt selectedProduct = 0.obs;

 


}
