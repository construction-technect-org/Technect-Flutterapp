// // lib/app/modules/home/bindings/home_binding.dart
// import 'package:construction_technect/app/modules/home/controller/home_controller.dart';
// import 'package:get/get.dart';

// class HomeBinding extends Bindings {
//   @override
//   void dependencies() {
//     Get.lazyPut<HomeController>(() => HomeController());
//   }
// }
