import 'package:get/get.dart';

class ConnectionInboxController extends GetxController {
  RxBool isLoading = false.obs;
}
