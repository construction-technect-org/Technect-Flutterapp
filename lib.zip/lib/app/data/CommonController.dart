import 'package:construction_technect/app/core/utils/imports.dart';

class CommonController extends GetxController {
  final hasProfileComplete = false.obs;
}
